<?php
$databaseHost = 'localhost';
$databaseName = 'db';
$databaseUsername = 'root';
$databasePassword = ''; // Kosongkan jika menggunakan XAMPP default

// Membuat koneksi ke server MySQL
$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);

// Memeriksa koneksi
if (!$mysqli) {
    die("Koneksi gagal: " . mysqli_connect_error());
} else {
    echo "";
}
?>
