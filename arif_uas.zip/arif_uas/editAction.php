<?php
// Include the database connection file
require_once("dbConnection.php");

if (isset($_POST['update'])) {
    // Escape special characters in a string for use in an SQL statement
    $id = mysqli_real_escape_string($mysqli, $_POST['id']);
    $name = mysqli_real_escape_string($mysqli, $_POST['name']);
    $age = mysqli_real_escape_string($mysqli, $_POST['age']);
    $email = mysqli_real_escape_string($mysqli, $_POST['email']);

    // Check for empty fields
    $errors = [];
    if (empty($name)) {
        $errors[] = "Name field is empty.";
    }
    if (empty($age)) {
        $errors[] = "Age field is empty.";
    }
    if (empty($email)) {
        $errors[] = "Email field is empty.";
    }

    if (!empty($errors)) {
        // Display errors using Bootstrap alerts
        echo '<!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Error</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
        </head>
        <body>';
        echo '<div class="container mt-5">';
        echo '<div class="alert alert-danger">';
        echo '<h4 class="alert-heading">Error!</h4>';
        echo '<ul>';
        foreach ($errors as $error) {
            echo "<li>$error</li>";
        }
        echo '</ul>';
        echo '</div>';
        echo '<a href="javascript:history.go(-1)" class="btn btn-secondary">Go Back</a>';
        echo '</div>';
        echo '<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>';
        echo '</body></html>';
    } else {
        // Update the database table
        $result = mysqli_query($mysqli, "UPDATE users SET `name` = '$name', `age` = '$age', `email` = '$email' WHERE `id` = $id");

        // Display success message
        echo '<!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Success</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
        </head>
        <body>';
        echo '<div class="container mt-5">';
        echo '<div class="alert alert-success text-center">';
        echo '<h4 class="alert-heading">Success!</h4>';
        echo "<p>Data updated successfully!</p>";
        echo '<a href="index.php" class="btn btn-primary">View Result</a>';
        echo '</div>';
        echo '</div>';
        echo '<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>';
        echo '</body></html>';
    }
}
?>
