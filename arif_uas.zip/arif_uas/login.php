<?php
// Sertakan koneksi ke database
require 'dbConnection.php';

session_start(); // Memulai session

// Cek apakah tombol login ditekan
if (isset($_POST['login'])) {
    $email = mysqli_real_escape_string($mysqli, $_POST['email']);
    $password = mysqli_real_escape_string($mysqli, $_POST['password']);

    // Query untuk memeriksa apakah email ada dalam database
    $cekEmail = mysqli_query($mysqli, "SELECT * FROM login WHERE email='$email'");

    // Periksa apakah query berhasil
    if (!$cekEmail) {
        die('Error dalam query: ' . mysqli_error($mysqli));
    }

    if (mysqli_num_rows($cekEmail) > 0) {
        // Email ditemukan, cek passwordnya
        $row = mysqli_fetch_assoc($cekEmail);
        if ($password === $row['password']) {
            // Jika password cocok, buat session dan redirect ke index.php
            $_SESSION['log'] = 'true';
            $_SESSION['email'] = $email; // Menyimpan email di session
            header('location:index.php');
            exit; // Pastikan eksekusi berhenti setelah redirect
        } else {
            // Jika password salah
            $error = "Password salah!";
        }
    } else {
        // Jika email tidak ditemukan
        $error = "Email tidak ditemukan!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Login</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow-lg border-0 rounded-lg">
                    <div class="card-header bg-primary text-white text-center">
                        <h3 class="font-weight-light my-4">Login</h3>
                    </div>
                    <div class="card-body">
                        <!-- Tampilkan pesan error jika ada -->
                        <?php if (isset($error)): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>

                        <form method="post" action="">
                            <div class="form-floating mb-3">
                                <input class="form-control" name="email" id="inputEmail" type="email" placeholder="name@example.com" required />
                                <label for="inputEmail">Email address</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input class="form-control" name="password" id="inputPassword" type="password" placeholder="Password" required />
                                <label for="inputPassword">Password</label>
                            </div>
                            <div class="d-flex align-items-center justify-content-between mt-4 mb-0">
                                <button type="submit" class="btn btn-primary" name="login">Login</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
