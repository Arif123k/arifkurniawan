<?php
// Sertakan koneksi ke database
require_once("dbConnection.php");

session_start(); // Memulai session

// Proses logout jika tombol logout ditekan
if (isset($_POST['logout'])) {
    session_unset(); // Menghapus semua data sesi
    session_destroy(); // Menghancurkan sesi
    header('location:login.php'); // Redirect ke halaman login
    exit;
}

// Fetch data in descending order (latest entry first)
$result = mysqli_query($mysqli, "SELECT * FROM users ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <!-- Alert for Database Connection -->
        <div class="row justify-content-center">
            <div class="col-md-8">
                <?php if (!$mysqli): ?>
                    <div class="alert alert-danger text-center" role="alert">
                        <h4 class="alert-heading">Koneksi Gagal</h4>
                        <p><?= mysqli_connect_error(); ?></p>
                    </div>
                <?php else: ?>
                    <div class="alert alert-success text-center" role="alert">
                        <h4 class="alert-heading">Koneksi Berhasil</h4>
                        <p>Terhubung ke database dengan sukses!</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Page Title and Add New Data Button -->
        <div class="row mt-4">
            <div class="col-md-12 text-center">
                <h2>Home Page</h2>
                
                <!-- Tombol Logout -->
                <?php if (isset($_SESSION['log']) && $_SESSION['log'] == 'true'): ?>
                    <form method="post" action="">
                        <button type="submit" class="btn btn-danger mt-2" name="logout">Logout</button>
                    </form>
                <?php endif; ?>

                <!-- Tombol Tambah Data -->
                <a href="add.php" class="btn btn-primary mt-2">Tambah Data Baru</a>
            </div>
        </div>

        <!-- Data Table -->
        <div class="row mt-4">
            <div class="col-md-12">
                <table class="table table-bordered table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th>Nama</th>
                            <th>Umur</th>
                            <th>Email</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Fetch the next row of a result set as an associative array
                        while ($res = mysqli_fetch_assoc($result)) {
                            echo "<tr>";
                            echo "<td>".$res['name']."</td>";
                            echo "<td>".$res['age']."</td>";
                            echo "<td>".$res['email']."</td>";    
                            echo "<td>
                                    <a href=\"edit.php?id=$res[id]\" class=\"btn btn-success btn-sm\">Edit</a>
                                    <a href=\"delete.php?id=$res[id]\" onClick=\"return confirm('Apakah Anda yakin ingin menghapus?')\" class=\"btn btn-danger btn-sm\">Delete</a>
                                  </td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
