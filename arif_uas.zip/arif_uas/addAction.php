<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php
// Include the database connection file
require_once("dbConnection.php");

if (isset($_POST['submit'])) {
    // Escape special characters in string for use in SQL statement	
    $name = mysqli_real_escape_string($mysqli, $_POST['name']);
    $age = mysqli_real_escape_string($mysqli, $_POST['age']);
    $email = mysqli_real_escape_string($mysqli, $_POST['email']);
		
    // Check for empty fields
    $errors = [];
    if (empty($name)) {
        $errors[] = "Name field is empty.";
    }
    if (empty($age)) {
        $errors[] = "Age field is empty.";
    }
    if (empty($email)) {
        $errors[] = "Email field is empty.";
    }

    if (!empty($errors)) {
        // Display errors using Bootstrap alerts
        echo '<div class="container mt-5">';
        echo '<div class="alert alert-danger">';
        echo '<h4 class="alert-heading">Error!</h4>';
        echo '<ul>';
        foreach ($errors as $error) {
            echo "<li>$error</li>";
        }
        echo '</ul>';
        echo '</div>';
        echo '<a href="javascript:self.history.back();" class="btn btn-secondary">Go Back</a>';
        echo '</div>';
    } else { 
        // If all the fields are filled (not empty) 

        // Insert data into database
        $result = mysqli_query($mysqli, "INSERT INTO users (`name`, `age`, `email`) VALUES ('$name', '$age', '$email')");
		
        // Display success message
        echo '<div class="container mt-5">';
        echo '<div class="alert alert-success text-center">';
        echo '<h4 class="alert-heading">Success!</h4>';
        echo '<p>Data added successfully!</p>';
        echo '<a href="index.php" class="btn btn-primary">View Result</a>';
        echo '</div>';
        echo '</div>';
    }
}
?>
<!-- Bootstrap JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
